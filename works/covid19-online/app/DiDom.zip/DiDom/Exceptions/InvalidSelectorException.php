<?php

namespace DiDom\Exceptions;

use Exception;

class InvalidSelectorException extends Exception
{
    //
}
